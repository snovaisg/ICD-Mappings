This is not the original readme file (there isn't one), but instead it explains the data source for the data in this folder.

Taken from [Center for Medicare & Medicaid Services](https://www.cms.gov/Medicare/Coding/ICD9ProviderDiagnosticCodes/codes), this data contains the list of all ICD9-CM codes version 32.